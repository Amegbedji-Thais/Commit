import java.util.Scanner;
class CompteurJours{
    public static void main(String[] args) {
        Scanner compteurJours=new Scanner(System.in);
        System.out.println("Entrez un mois");
        String m=compteurJours.nextLine();
        if(m=="Janvier" || m=="Mars" || m=="Mai" || m=="Juillet" || m=="Aout" || m=="Octobre" || m=="Decembre"){
            System.out.println("Ce mois compte 31 jours");
        }
        else if(m=="Avril" || m=="Juin" || m=="Septembre" || m=="Novembre"){
            System.out.println("Ce mois compte 30 jours");
        }
        else if(m=="Fevrier"){
            System.out.println("Entrez une annee");
            int a=compteurJours.nextInt();
            if(a%400==0){
                System.out.println("Ce mois compte 29 jours");
            }
            else if(a%4==0 && a%100==0 && a%400==0){
                System.out.println("Ce mois compte 29 jours");
            }
            else if(a%4==0 && a%100!=0){
                System.out.println("Ce mois compte 29 jours");
            }
            else{
                System.out.println("Ce mois compte 28 jours");
            }
        }
        else{
            System.out.println("Impossible");
        }
    }
}