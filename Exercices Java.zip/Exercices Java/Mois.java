import java.util.Scanner;
class Mois{
    public static void main(String[] args) {
        Scanner mois=new Scanner(System.in);
        System.out.println("entrez un entier");
        int m=mois.nextInt();
        if(m==1){
            System.out.println("1-->Janvier");
        }
        else if(m==2){
            System.out.println("2-->Fevrier");
        }
        else if(m==3){
            System.out.println("3-->Mars");
        }
        else if(m==4){
            System.out.println("4-->Avril");
        }
        else if(m==5){
            System.out.println("5-->Mai");
        }
        else if(m==6){
            System.out.println("6-->Juin");
        }
        else if(m==7){
            System.out.println("7-->Juillet");
        }
        else if(m==8){
            System.out.println("8-->Aout");
        }
        else if(m==9){
            System.out.println("9-->Septembre");
        }
        else if(m==10){
            System.out.println("10-->Octobre");
        }
        else if(m==11){
            System.out.println("1-->Novembre");
        }
        else if(m==12){
            System.out.println("12-->Decembre");
        }
        else{
            System.out.println("Inexistant");
        }
    }
}