import java.util.Scanner;
class OrdreCroissant{
    public static void main(String[] args) {
        Scanner ordreCroissant=new Scanner(System.in);
        System.out.println("Entrez un premier entier");
        int x1=ordreCroissant.nextInt();
        System.out.println("Entrez un deuxieme entier");
        int x2=ordreCroissant.nextInt();
        System.out.println("Entrez un troisieme");
        int x3=ordreCroissant.nextInt();
        if(x1<x2 && x1<x3 && x2<x3){
            System.out.println("Ordre croissant");
            System.out.print(x1);
            System.out.print("-->");
            System.out.print(x2);
            System.out.print("-->");
            System.out.println(x3);
            System.out.println("Ordre decroissant");
            System.out.print(x3);
            System.out.print("-->");
            System.out.print(x2);
            System.out.print("-->");
            System.out.println(x1);
        }
        else if (x2<x1 && x1<x3 && x2<x3){
            System.out.println("Ordre croissant");
            System.out.print(x2);
            System.out.print("-->");
            System.out.print(x1);
            System.out.print("-->");
            System.out.println(x3);
            System.out.println("Ordre decroissant");
            System.out.print(x3);
            System.out.print("-->");
            System.out.print(x1);
            System.out.print("-->");
            System.out.println(x2);
        }
        else if(x3<x1 && x1<x2 && x3<x2){
            System.out.println("Ordre croissant");
            System.out.print(x3);
            System.out.print("-->");
            System.out.print(x1);
            System.out.print("-->");
            System.out.println(x2);
            System.out.println("Ordre decroissant");
            System.out.print(x2);
            System.out.print("-->");
            System.out.print(x1);
            System.out.print("-->");
            System.out.println(x3);

        }
        else if(x1<x3 && x3<x2 && x1<x2){
            System.out.println("Ordre croissant");
            System.out.print(x1);
            System.out.print("-->");
            System.out.print(x3);
            System.out.print("-->");
            System.out.println(x2);
            System.out.println("Ordre decroissant");
            System.out.print(x2);
            System.out.print("-->");
            System.out.print(x3);
            System.out.print("-->");
            System.out.println(x1);

        }
        else if(x2<x3 && x3<x1 && x2<x1){
            System.out.println("Ordre croissant");
            System.out.print(x2);
            System.out.print("-->");
            System.out.print(x3);
            System.out.print("-->");
            System.out.println(x1);
            System.out.println("Ordre Decroissant");
            System.out.print(x1);
            System.out.print("-->");
            System.out.print(x3);
            System.out.print("-->");
            System.out.println(x2);

        }
        else{
            System.out.println("ordre croissant");
            System.out.print(x3);
            System.out.print("-->");
            System.out.print(x2);
            System.out.print("-->");
            System.out.print(x1);
            System.out.println("Ordre decroissant");
            System.out.print(x1);
            System.out.print("-->");
            System.out.print(x2);
            System.out.print("-->");
            System.out.print(x3);

        }
    }
}